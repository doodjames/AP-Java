// ***************************************************************
// Shop.java
//
// Uses the Item class to create items and add them to a shopping
// cart stored in an ArrayList.
// ***************************************************************
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.text.NumberFormat;
public class Shop
{
    public static void main (String[] args)
    {
    // *** Declare and instantiate a variable cart to be an empty ArrayList
    NumberFormat fmt = NumberFormat.getCurrencyInstance();
    String work1;
    double totalPrice = 0;
    String itemName;
    double itemPrice;
    int quantity;
    String keepShopping = "y";
    ArrayList cart = new ArrayList();
    work1 = ("\nItem Name\tItem Price\tItem Quantity");
    cart.add(work1);
    do{
        itemName = JOptionPane.showInputDialog("Enter the name of the item: ");
        String temp = JOptionPane.showInputDialog("Enter the unit price: ");    
        itemPrice = Double.parseDouble(temp);
        temp = JOptionPane.showInputDialog("Enter the quantity: ");
        quantity = Integer.parseInt(temp);
        // *** create a new item and add it to the cart
        Item item = new Item(itemName, itemPrice, quantity);
        totalPrice += (item.getPrice() * item.getQuantity());
        // *** print the contents of the cart object using println
        String work2 = ("\n " + item.getName() + "\t\t" + fmt.format(item.getPrice()) + "\t\t" + item.getQuantity() + "\n");
        cart.add(work2);
        System.out.print(cart);
        System.out.println("\nThe total price is: " + fmt.format(totalPrice));
        
        
        
        
        keepShopping = JOptionPane.showInputDialog("Continue shopping (y/n)? ");
    }
    while (keepShopping.equalsIgnoreCase("y"));
    
    }
}
