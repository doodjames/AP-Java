// **********************************************************
// Player.java
//
// Defines a Player class that holds information about an athlete.
// **********************************************************

public class Player
{
    private String name;
    private String team;
    private int jerseyNumber;


    //-----------------------------------------------------------
    // Prompts for and reads in the player's name, team, and 
    // jersey number.
    //-----------------------------------------------------------

    public void readPlayer()
    {

	name = GetInfoV4.getString("Name: ");

	team = GetInfoV4.getString("Team: ");

	jerseyNumber = GetInfoV4.getInt("Jersey number: ");

    }
    public String getName(){
        return name;
    }
    
    public String getTeam(){
        return team;
    }
    
    public int getJersey(){
        return jerseyNumber;
    }
    
    public boolean equals(Player otherPlayer){
       if((this.getJersey() == otherPlayer.getJersey()) && (otherPlayer.getTeam().equals(team))){
           return true;
       } 
       else{
           return false;
       }
    }

}

