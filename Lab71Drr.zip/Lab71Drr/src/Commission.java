/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rrahm
 */
import java.text.NumberFormat;

public class Commission extends Hourly{
    
    double totalSales;
    double comrate;
    double sales;
    NumberFormat fmt = NumberFormat.getCurrencyInstance();

    
    public Commission(String eName, String eAddress, String ePhone, String socSecNumber, double rate, double comrate1) {
        super(eName, eAddress, ePhone, socSecNumber, rate);
        comrate = comrate1;
    }
    
    public void addSales (double totalSales){
        sales += totalSales;
    }
    
    public double pay(){ 	
    	double pay1= (super.pay())+ (comrate * sales);
    	sales = 0;
    	return pay1;
    }
    
    public String toString(){
        double compay = comrate * sales;
        double hourpay = hoursWorked * payRate;
        String work = (super.toString() + "\nTotal Sales: " + fmt.format(sales) + "\nTotal Commission: " + fmt.format(compay) + "\nTotal Hourly: " + fmt.format(hourpay) + "\nTotal Paid: " + fmt.format(this.pay()));
        return work;
    }
    
    
}
