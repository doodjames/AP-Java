/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rrahm
 */
public class MultChoice extends TestQuestion{
    String[] answers;
    String[] choices = {"Across", "Down"};
    int layout;
    
    public MultChoice(int size){
        super();
        answers = new String[size];
        
        for(int i = 0; i < answers.length; i++){
            answers[i] = GetInfoV4.getString("Enter answer of number " + (i+1));
        }
        layout = GetInfoV4.getOption("How is this answer printed? ", choices);
    
}
    protected String printString(){
        String work = (question + "\n");
        if(layout == 0){
            for(int ii = 0; ii < answers.length; ii++){
                work += ((ii+1) + ") " + answers[ii] + "\t");
            }
            work += ("\n\n");
        }
        else if(layout == 1){
            for(int iii = 0; iii < answers.length; iii++){
                work += ((iii+1) + ") " + answers[iii] + "\n");
            }
            work += ("\n");
        }
        return work;
    }
    
}
