// ****************************************************************
// TestQuestion.java
// ****************************************************************
public abstract class TestQuestion
{
    protected String question;
    //----------------------------------------------------------------------- 
    // Constructor -- INPUT the question  here in the driver.
    //----------------------------------------------------------------------- 
    public TestQuestion()
    {
	question = GetInfoV4.getString("INPUT the Question here: ");
    }
    //----------------------------------------------------------------------- 
    //  Abstract Method  -  Will format output depending on object Essay/MC. 
    //----------------------------------------------------------------------- 
    protected abstract String printString();
}

