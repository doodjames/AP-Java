/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rrahm
 */
public class Essay extends TestQuestion {
    
    int numBlanks;
    
    public Essay (int nbrofBlanks){
        super();
        numBlanks = nbrofBlanks;
        
    }
      
    public String printString(){
        String work = (question + "\n");
        for(int i = 0; i < numBlanks; i++){
            work += ("\n");
        }
        return work;
    }
    
    
    
}
