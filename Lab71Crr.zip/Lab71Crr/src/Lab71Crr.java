/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author rrahm
 */
public class Lab71Crr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int sizeTest = GetInfoV4.getSlider("Enter the number of questions: ",0,10);
           
        int numLines = 0;
        int numChoice = 0;
        TestQuestion[] myTest = new TestQuestion[50];
        
        for(int i = 0; i < sizeTest; i++) {
            
            String[] choices = {"Essay", "MC"};
            int typeTest = GetInfoV4.getOption("Is #" + (i+1) + " an essay or multiple choice?",choices);
            
            
            if(typeTest == 0) {
                numLines = GetInfoV4.getSlider("Amount of blank lines for this essay: ",1,5);
                Essay question = new Essay(numLines);
                myTest[i] = question;
            }
            else if(typeTest == 1) {
                numChoice = GetInfoV4.getSlider("Amount of choices for this multiple choice: ",0,5);
                MultChoice question = new MultChoice(numChoice);
                myTest[i] = question;
            }
        }      
        String work = ("test questions: \n");
        for(int ii=0; ii < sizeTest; ii++) {
            work += myTest[ii].printString();
        }
        
        
        
        GetInfoV4.showMessage(work);
    
    
    }
    
}
