/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.text.NumberFormat;

/**
 *
 * @author rrahm
 */
public class Lab63Arr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double totalPrice = 0;
        ShoppingCart cart = new ShoppingCart();
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        do{
            
             String itemName = GetInfoV4.getString ("Enter in the name of the item");
             int itemAmnt = GetInfoV4.getInt ("Enter the amount of items you want to purchase");
             double itemPrice = GetInfoV4.getDouble ("Enter in the price of the item");
             
             cart.addToCart(itemName, itemPrice, itemAmnt);
             
                     
             totalPrice += (itemPrice * itemAmnt);
             cart.printString();
        }    
        while(GetInfoV4.getYesNo("Do you want to continue: "));
        
        GetInfoV4.showMessage("Please pay: " + fmt.format(totalPrice));
    }
    
}
