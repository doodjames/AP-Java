// **********************************************************************
//   ShoppingCart.java
//
//   Represents a shopping cart as an array of items
// **********************************************************************

import java.text.NumberFormat;

public class ShoppingCart
{

    private int itemCount;      // total number of items in the cart
    private double totalPrice;  // total price of items in the cart
    private int capacity;       // current cart capacity
    private Item[] cart = new Item[capacity];
    // -----------------------------------------------------------
    //  Creates an empty shopping cart with a capacity of 5 items.
    // -----------------------------------------------------------
    public ShoppingCart()
    {
	capacity = 5;
	itemCount = 0;
	totalPrice = 0.0;


    }

    // -------------------------------------------------------
    //  Adds an item to the shopping cart.
    // -------------------------------------------------------
    public void addToCart(String itemName, double price, int quantity)
    {
        increaseSize();
        
        totalPrice += (quantity * price);
        
        Item temp = new Item(itemName, price, quantity);
        
            for(int i = 0; i < cart.length; i++){
                if(cart[i] == null){
                    cart[i] = temp;
                    itemCount++;
                    i = cart.length;
                }

                

            }
        

    }

    // -------------------------------------------------------
    //  Returns the contents of the cart together with
    //  summary information.
    // -------------------------------------------------------
    public void printString()
    {
	NumberFormat fmt = NumberFormat.getCurrencyInstance();
	System.out.println("\nShopping Cart\n");
	System.out.println("\nItem\t\tUnit Price\tQuantity\tTotal\n");

	for (int i = 0; i < itemCount; i++)
		{
			cart[i].printString();
		}

	System.out.println("\nTotal Price: " + fmt.format(totalPrice) + "\n");

    }

    // ---------------------------------------------------------
    //  Increases the capacity of the shopping cart by 3
    // ---------------------------------------------------------
    private void increaseSize()
    {
        Item[] temp = new Item[capacity + 3];
        for(int i = 0; i < temp.length; i++){
            if(i < cart.length){
                temp[i] = cart[i]; 
            }
            else{
                temp[i] = null;
            }

        }
        cart = temp;
    }

}
