//*** SKELETON ******************************
// 		Filter.java
//*******************************************


public class Filter
{
  //-------------------------------------------
  // Take a String “Mississippi” remove ALL “ss”
  //-------------------------------------------
public String Filter(String str, String pattern)
  {
      String work = "";

        int tempIndex = str.indexOf(pattern);
        if(tempIndex == -1){
            
            return work += str; 
        }
        else{
            String tempStr = str.replace(pattern, "");
            return work += tempStr;
        }

      







  }
 } 
