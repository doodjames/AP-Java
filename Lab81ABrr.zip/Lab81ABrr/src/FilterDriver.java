//*** SKELETON *******************************
//   FilterDriver.java
//********************************************
 
public class FilterDriver
{
public static void main(String[] args)
{
    String work;
    Filter filterObj = new Filter();
    work = (filterObj.Filter("Mississippi", "ss"));
    System.out.println(work);


}
}

