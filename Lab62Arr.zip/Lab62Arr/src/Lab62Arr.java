// ****************************************************************
// SquareTest.java
//
// Uses the Square class to read in square data and tell if
// each square is magic.
//
// ****************************************************************
public class Lab62Arr
{
 public static void main(String[] args)
 {
int count = 1; //count which square we're on
System.out.println("Entering a 3 for the size, means you are creating a 3 x 3 array");
int size = GetInfoV4.getInt("Enter the size of the array, or a -1 to terminate the program");
//Enter a -1 to terminate the program
while (size != -1)
 {
//create a new Square of the given size
  Square square = new Square(size);
//call its read method to read the values of the square
square.readSquare();
System.out.println("\n******** Square " + count + " ********");
//print the square
square.printSquare();
//print the sums of its rows
for(int row = 0; row < size; row++){
    System.out.println("The sum of row " + row + " is: " + square.sumRow(row));
}
//print the sums of its columns
for(int col = 0; col < size; col++){
    System.out.println("The sum of column " + col + " is: " + square.sumCol(col));
}
//print the sum of the main diagonal
System.out.println("The sum of the main diagonal is: " + square.sumMainDiag());
//print the sum of the other diagonal
System.out.println("The sum of the other diagonal is: " + square.sumOtherDiag());
//determine and print whether it is a magic square
System.out.println("Square = magic?: " + square.magic());
//get size of next square
size = GetInfoV4.getInt("Enter the size of the array, or a -1 to terminate the program");
 }
 }
}
