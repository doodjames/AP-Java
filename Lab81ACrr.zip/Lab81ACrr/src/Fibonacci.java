//*** SKELETON ******************************
//
// 		Fibonacci.java
//
//*******************************************
 
public class Fibonacci
{
    
  int temp = 0;
  int temp2 = 1;
  int sum1 = 1;
  String work = "\n ";
  //-------------------------------------------
  //Print first 10 terms of Fibonacci Sequence
  //-------------------------------------------
   public String Fibonacci(int fibCount)
  {
    if(fibCount == 0)
    {
  	return work;
    }
    else
    {	
  	temp2 = sum1;
  	work += (sum1 + ", ");
  	sum1 = temp + sum1;
  	temp = temp2;
  	fibCount = fibCount - 1;
  	Fibonacci(fibCount);
  	return work;
  	} 
  }
 }

