//*** SKELETON **********************************
//   FibDriver.java
//*************************************************
 
public class FibDriver
{
    public static void main(String[] args)
    {
 
	Fibonacci myObj = new Fibonacci(); 
 
        System.out.println(myObj.Fibonacci(10));

	
    }
}

