//*** SKELETON ******************************
// 		CheerLeader.java
//*******************************************
public class CheerLeader
{
    int tempSum = 0;
    int tempSum2 = 2;
    String work = "\n ";
  //-------------------------------------------
  //Print “2 4 6 8 Who do we appreciate”
  //-------------------------------------------
   public String CheerLeader(int i)
  {
      if(i == 0){
          return work;
      }
      else{
          tempSum = tempSum2;
          work = work + (tempSum2 + " ");
          tempSum2 = tempSum2 + 2;
          i--;
          CheerLeader(i);
          return work;
                
      }



  }
 } 
