//*** SKELETON *******************************
//   CheerDriver.java
//********************************************
 
public class CheerDriver
{
    public static void main(String[] args)
    {
	CheerLeader cheerObj = new CheerLeader(); 
	System.out.println(cheerObj.CheerLeader(4) + "who do we appreiciate");
        
    }
}

