// ***** LAB6POINT1E *********************************************
// IntegerList.java
//
// Define an IntegerList class with methods to create, fill,
// sort, and search in a list of integers.
//
// ****************************************************************
public class IntegerList{
 int[] list; //values in the list
 int[] xsize;
 int[] temp;
 //-------------------------------------------------------
 //CONSTRUCTOR - create a list of the given size
 //-------------------------------------------------------
 public IntegerList(int size)
 {
list = new int[size];
 }
 //-------------------------------------------------------
 //fill array with integers between 1 and 100, inclusive
 //-------------------------------------------------------
 public void randomize()
 {
for (int i=0; i<list.length; i++)
 list[i] = (int)(Math.random() * 100) + 1;
 }
 //-------------------------------------------------------
 //print array elements with indices
 //-------------------------------------------------------
 public void print()
 {
     String myString = new String("");
     String myDetail;
     
for (int i=0; i<list.length; i++)
    {
        myDetail = new String(i + ":\t" + list[i] + "\n");
        myString = myString + myDetail;
        
    } 
    
    myString = myString + ("\n");
    
    GetInfoV4.showMessage(myString);

}
 //-------------------------------------------------------
 //return the index of the first occurrence of target in the list.
 //return -1 if target does not appear in the list
 //-------------------------------------------------------
 public int search(int target)
 {
int location = -1;
for (int i=0; i<list.length && location == -1; i++)
 if (list[i] == target)
location = i;
return location;
 }
 //-------------------------------------------------------
 //sort the list into ascending order using the selection sort algorithm
 //-------------------------------------------------------
 public void selectionSort()
 {

    int minIndex;
    for (int i=0; i < list.length-1; i++)
    {
       //find smallest element in list starting at location i
        minIndex = i;
        for (int j = i+1; j < list.length; j++)
        {
            if (list[j] < list[minIndex]){
            minIndex = j;
            }
        }
        //swap list[i] with smallest element
        int temp = list[i];
        list[i] = list[minIndex];
        list[minIndex] = temp; 
   
    }

        this.print();
    
 }

 public void increaseSize()
{
	temp = new int[list.length +1];
	for(int x = 0; x < list.length; x++)
	{
		temp[x] = list[x];
	}
	list = temp;	
}
	
public void addElement(int newVal)
{
		
	int length = list.length;
	increaseSize();
		
	list[length] = newVal;
				
}

public void removeFirst(int newVal)
{
    
    int i = 0;
    int location;
    
    while(i < list.length && i != 999){
            if(list[i] == newVal)
            {
                list[i] = 999;
                location = i;
                i = 999;
                selectionSort();
            }
            else{ i++; }
            
            
    }
    
    	 
}

public void removeAll(int newVal)
{
	int location = -1;
	int counter = 0;
	int firstloc = 0;
	int zzz;
    	int i = 0;
        
        
            for(int y = list.length - 1; y>0; y--)
            {
                while(i < list.length){
                    if(list[i] == newVal){
                        list[i] = 999;
                        location = i;
                
                
                    }
                i++;
                }
                
                
                list[list.length - 1] = 999;
            }
            zzz = location;
            while(zzz < list.length-1)
            {
                    temp[zzz] = list[zzz+1];
                    zzz++;
            }	
            list = temp;
            
            
        
}

public void addInOrder(int newVal)
{

    int length = list.length;
    increaseSize();
		
    list[length] = newVal;
    selectionSort();
    
    
    
    int location = 0;
    int x = 0;
   
		
    while(x < list.length)
	{
            if(list[x] < newVal)
            { 	
	   	if(x == list.length -1)
	   	{
                    location = x;
	   	}
	   	else
	   	{
                    x++;
	   	}
	   		 
	    }

            if(list[x] > newVal)
	    {	 	
	   	location = x;
	    }
	    if(location != 0)
	    {
                x=999;
            }
            if(list[x] == list[list.length - (list.length-1)])
            {
                location = 0;
            }
	   	
	}
	
	    

    if(location == list.length)
    {
        list[(location - 1)] = newVal;
    }
    else
    {
	for(x =list.length-1; x>location;x--)
	{
	    	
            list[x] = list[x-1]; 
            print();
	}
	list[location] = newVal;
    }
	    
}










}

