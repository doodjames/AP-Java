// **** LAB6POINT1E DRIVER *************************************
// IntegerListTest.java
//
// Provide a menu-driven tester for the IntegerList class.
//
// ****************************************************************
public class Lab61Err{
static IntegerList list = new IntegerList(10);
 //-------------------------------------------------------
 // Create a list, then repeatedly print the menu and do what the
 // user asks until they quit
 //-------------------------------------------------------
 public static void main(String[] args)
 {
printMenu();
int choice = GetInfoV4.getInt("Enter your choice");
while (choice != 0)
 {
dispatch(choice);
printMenu();
choice = GetInfoV4.getInt("Enter your choice");
 }
 }
 //-------------------------------------------------------
 // Do what the menu item calls for
 //-------------------------------------------------------
 public static void dispatch(int choice)
 {
int loc;
switch(choice)
 {
 case 0:
GetInfoV4.showMessage("Bye!");
break;
 case 1:
int size = GetInfoV4.getInt("How big should the list be?");
list = new IntegerList(size);
list.randomize();
break;
 case 2:
list.selectionSort();
break;
 case 3:
loc = list.search(GetInfoV4.getInt("Enter the value to look for: "));
if (loc != -1)
 GetInfoV4.showMessage("Found at location " + loc);
else
 GetInfoV4.showMessage("Not in list");
break;
 case 4:
System.out.println(" ");
list.print();
break;

 case 5:
int Valu =0;
int wfrewf = 1;

while(wfrewf == 1)
{
    Valu = GetInfoV4.getInt("Please enter your new value");
    if(Valu > 100)
    {
        GetInfoV4.showMessage("You must eneter a value between 1 and 100");
    }
    else
    {
        wfrewf = 0;
    }

} 

list.addElement(Valu);
break; 
 
 case 6:
int Val2=0;
	    	
wfrewf = 1;
while(wfrewf == 1)
{
    Val2 = GetInfoV4.getInt("Enter the value you would like to remove");
    if(Val2>100)
    {
	GetInfoV4.showMessage("You must eneter a value between 1 and 100");
    }
    else
    {
	wfrewf = 0;
    }
	    	
} 

list.removeFirst(Val2);
break;
 
 case 7:
int yy=0;
wfrewf = 1;
while(wfrewf == 1)
{
    yy = GetInfoV4.getInt("Enter the value you would like to remove");
    if(yy>100)
    {
	GetInfoV4.showMessage("You must eneter a value between 1 and 100");
    }
    else
    {
	wfrewf = 0;
    }
	    	
} 
	    	
list.removeAll(yy);
break;

 case 8:
int yz = 0;
wfrewf = 1;
while(wfrewf == 1)
{
    yz = GetInfoV4.getInt("Enter the value you would like to add");
    if(yz > 100)
    {
	GetInfoV4.showMessage("You must eneter a value between 1 and 100");
    }
    else
    {
	wfrewf = 0;
    }
	    	
} 
list.addInOrder(yz);
break;
 
 default:
GetInfoV4.showMessage("Sorry, invalid choice");
 }
 }
 //-------------------------------------------------------
 // Print the user's choices
 //-------------------------------------------------------
 public static void printMenu()
 {
System.out.println("\n Menu ");
System.out.println(" ====");
System.out.println("0: Quit");
System.out.println("1: Create a new list (** do this first!! **)");
System.out.println("2: Sort the list using selection sort");
System.out.println("3: Find an element in the list using sequential search");
System.out.println("4: Print the list");
System.out.println("5: Add an element to the list");
System.out.println("6: Remove the first occurance of an element from the list");
System.out.println("7: Remove all occurances of an element from the list");
System.out.println("8: Add an element to the list while sorting it");
System.out.print("\nEnter your choice: ");
 }
}